Config = {}
 
Config.SafeZones = {
    {
        coords = vector3(-266.592, -961.001, 31.223),
        radius = 100.0
    },
}
 
