fx_version 'cerulean'
game 'gta5'

author '𝑵𝑶𝑿 𝑪𝑭𝑾'
description 'Safe Zone System'
version '1.0.0'

shared_script 'config.lua'

client_script 'client.lua'
server_script 'server.lua'

lua54 'yes'