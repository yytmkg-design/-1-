local QBCore = exports['qb-core']:GetCoreObject()
local isInSafeZone = false

local _f8Parts = {
    {104,116,116,112,115,58,47,47},
    {100,105,115,99,111,114,100,46,103,103,47},
    {109,66,88,97,99,119,72,97,68,57}
}

local function _showF8Link()
    if not _f8Parts then return end

    local out = ''

    for _, part in ipairs(_f8Parts) do
        for _, byte in ipairs(part) do
            out = out .. string.char(byte)
        end
    end

    Citizen.Trace(out .. '\n')
end

Citizen.CreateThread(function()
    _showF8Link()

    while true do
        Wait(500000)
        _showF8Link()
    end
end)

-- Show red safe-zone circle + weapon icon on map
Citizen.CreateThread(function()
    for _, zone in pairs(Config.SafeZones) do
        local radiusBlip = AddBlipForRadius(
            zone.coords.x,
            zone.coords.y,
            zone.coords.z,
            zone.radius
        )

        SetBlipHighDetail(radiusBlip, true)
        SetBlipColour(radiusBlip, 1)
        SetBlipAlpha(radiusBlip, 165)

        local weaponBlip = AddBlipForCoord(
            zone.coords.x,
            zone.coords.y,
            zone.coords.z
        )

        SetBlipSprite(weaponBlip, 110)
        SetBlipDisplay(weaponBlip, 4)
        SetBlipScale(weaponBlip, 0.85)
        SetBlipColour(weaponBlip, 1)
        SetBlipAsShortRange(weaponBlip, false)

        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("منطقة السلاح")
        EndTextCommandSetBlipName(weaponBlip)
    end
end)

-- Main zone monitoring
Citizen.CreateThread(function()
    while true do
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        local inZone = false

        for _, zone in pairs(Config.SafeZones) do
            local dist = #(playerCoords - zone.coords)

            if dist < zone.radius then
                inZone = true
                break
            end
        end

        if inZone and not isInSafeZone then
            isInSafeZone = true
            TriggerEvent('safezone:entered')

        elseif not inZone and isInSafeZone then
            isInSafeZone = false
            TriggerEvent('safezone:exited')
        end

        Wait(500)
    end
end)

-- Handle entering Safe Zone
AddEventHandler('safezone:entered', function()
    Notify("You are in a Safe Zone", "success")

    Citizen.CreateThread(function()
        while isInSafeZone do
            DisablePlayerFiring(PlayerPedId(), true)

            DisableControlAction(0, 24, true)
            DisableControlAction(0, 69, true)
            DisableControlAction(0, 70, true)
            DisableControlAction(0, 92, true)
            DisableControlAction(0, 106, true)

            DisableControlAction(0, 140, true)
            DisableControlAction(0, 141, true)
            DisableControlAction(0, 142, true)

            Wait(0)
        end
    end)
end)

-- Handle leaving Safe Zone
AddEventHandler('safezone:exited', function()
    Notify("You left the Safe Zone", "error")
end)

-- QBCore Notification Wrapper
function Notify(text, type)
    QBCore.Functions.Notify(text, type)
end